from project.customer import Customer
from project.equipment import Equipment
from project.exercise_plan import ExercisePlan
from project.subscription import Subscription
from project.trainer import Trainer


class Gym:
    def __init__(self):
        self.customers = []
        self.trainers = []
        self.equipment = []
        self.plans = []
        self.subscriptions = []

    def add_customer(self, customer: Customer):
        if customer in self.customers:
            return
        self.customers.append(customer)

    def add_trainer(self, trainer: Trainer):
        if trainer in self.trainers:
            return
        self.trainers.append(trainer)

    def add_equipment(self, equipment: Equipment):
        if equipment in self.equipment:
            return
        self.equipment.append(equipment)

    def add_plan(self, plan: ExercisePlan):
        if plan in self.plans:
            return
        self.plans.append(plan)

    def add_subscription(self, subscription: Subscription):
        if subscription in self.subscriptions:
            return
        self.subscriptions.append(subscription)

    def subscription_info(self, subscription_id: int):
        subscription = self.__finder(self.subscriptions, subscription_id)
        result = repr(subscription) + '\n'

        customer = self.__finder(self.customers, subscription.customer_id)
        result += repr(customer) + '\n'

        trainer = self.__finder(self.trainers, subscription.trainer_id)
        result += repr(trainer) + '\n'

        exercise_plan = self.__finder(self.plans, trainer.id)
        equipment = self.__finder(self.equipment, exercise_plan.equipment_id)
        result += repr(equipment) + '\n'

        result += repr(exercise_plan)
        return result

    def __finder(self, entities, entity_id):
        for entity in entities:
            if entity.id == entity_id:
                return entity